package Minhaagencia.viagens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViagensApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViagensApplication.class, args);
	}

}
